
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/track.mjs
var track_default = async (req) => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }
  try {
    const body = await req.json();
    const { action, filter, timestamp } = body;
    if (!action) {
      return new Response(JSON.stringify({ error: "missing action" }), { status: 400 });
    }
    const { getStore } = await import("@netlify/blobs");
    const store = getStore("analytics");
    let raw = await store.get("events", { consistency: "strong" });
    let events = raw ? JSON.parse(raw) : [];
    events.push({
      action,
      filter: filter || "unknown",
      timestamp: timestamp || Date.now(),
      ip: req.headers.get("x-nf-client-connection-ip") || "unknown",
      ua: req.headers.get("user-agent")?.slice(0, 120) || "unknown",
      date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
    });
    if (events.length > 1e4) {
      events = events.slice(-1e4);
    }
    await store.set("events", JSON.stringify(events));
    return new Response(JSON.stringify({ ok: true, total: events.length }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (e) {
    console.error("Track error:", e);
    return new Response(JSON.stringify({ error: e.message }), { status: 500 });
  }
};
export {
  track_default as default
};
